// move your mose to move the lamp 
// inspired by https://dribbble.com/shots/7096286-Spectrum-concept

console.clear();

let tilt = false; // tilt the lamp!
let ready = false;


const lamp = document.querySelectorAll('.lamp')[0];
const highlight = document.querySelectorAll('.grid-highlight')[0];
const tiltBtn = document.querySelectorAll('.tilt-btn')[0];

let transitionTime = 2;
let ease = Power4.easeOut;

let lastX, threshold = 50;


const move = e => {
	if (!ready) return;
	let xPos = e.clientX;
	let offset = 0;
	
	if (tilt) {
		if (lastX < xPos - 1) {
			lamp.classList.remove('lamp--to-left');
			lamp.classList.add('lamp--to-right');
			offset = 200;
		} else if (lastX > xPos + 1) {
			lamp.classList.remove('lamp--to-right');
			lamp.classList.add('lamp--to-left');
			offset = -200;
		} else {
			lamp.classList.remove('lamp--to-right', 'lamp--to-left');
		}
	}
	
	TweenMax.to(lamp, transitionTime, {
		x: xPos - lamp.offsetWidth / 2,
		ease: ease
	});
	TweenMax.to(highlight, transitionTime, {
		x: (xPos - highlight.offsetWidth / 2) + offset,
		ease: ease
	});
	
	lastX = xPos;
}

document.addEventListener('mousemove', move);

tiltBtn.addEventListener('click', function() {
	if (tilt) {
		tilt = false;
		tiltBtn.classList.add('tilt-btn--off');
		lamp.classList.remove('lamp--to-right', 'lamp--to-left');
	} else {
		tilt = true;
		tiltBtn.classList.remove('tilt-btn--off');
	}
});


/* intro movement */
const intro = () => {
	let xPos = window.innerWidth / 2;
	const tl = new TimelineMax();
	tl.set(lamp, {x: xPos});
	tl.to(lamp, transitionTime, {
		x: (xPos * 1.8) - lamp.offsetWidth / 2,
		ease: ease
	});
	tl.to(highlight, transitionTime, {
		x: (xPos * 1.8) - highlight.offsetWidth / 2,
		ease: ease
	}, `-=${transitionTime}`);
	
	tl.to(lamp, transitionTime, {
		x: (xPos * 0.5) - lamp.offsetWidth / 2,
		ease: ease
	}, `-=${transitionTime / 2}`);
	tl.to(highlight, transitionTime, {
		x: (xPos * 0.5) - highlight.offsetWidth / 2,
		ease: ease,
		onComplete: function() {
			ready = true;
		}
	}, `-=${transitionTime}`);
	
	
	lastX = xPos;
}
intro();