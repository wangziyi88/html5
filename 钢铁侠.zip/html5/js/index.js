var tl = new TimelineMax({ repeat: 0 }), tl_sky = new TimelineMax({ repeat: -1 });

//小火苗抖动
TweenMax.fromTo(".fire", .03, { x: -.6, y: -.5 }, { x: .6, y: .5, repeat: -1, yoyo: true });

//背景天空向上走动
tl_sky.fromTo(".sky", 10, { transform: "translateY(-100vh)" }, { transform: "translateY(0vh)", ease: Power0.easeNone });

//动画的速度倍数
tl_sky.timeScale(0.5);

//机器人运动
tl.to(".rocket", 3, { transform: "translateY(-3vh)", ease: Expo.easeOut })
    .fromTo(".fire", .4, { scaleY: .8 }, { scaleY: 1.5 }, "-=0.4")
    .add(() => tl_sky.timeScale(5))
    .add(() => tl_sky.timeScale(10), "+=0.2")
    .add(() => tl_sky.timeScale(15), "+=0.1")
    .add(() => tl_sky.timeScale(20), "+=0.1")
    .add(() => tl_sky.timeScale(25), "+=0.1")
    .to(".rocket", 1, { transform: "translateY(-100vh)", ease: Power3.easeOut }, "+=1.5")
    .add(() => TweenMax.to(tl_sky, 1.0, { timeScale: 25 }))
    .add(() => TweenMax.to(tl_sky, 1.0, { timeScale: 10 }))
    .add(() => TweenMax.to(tl_sky, 1.0, { timeScale: 0 }))
    .add(()=>{
        tl.fromTo(".pageContent", 2, { transform: "translateY(0vh)" }, { transform: "translateY(-100vh)", ease: Power0.easeNone });
    })

var num = 0
setInterval(()=>{
    num ++ 
    console.log(num)
},1000)